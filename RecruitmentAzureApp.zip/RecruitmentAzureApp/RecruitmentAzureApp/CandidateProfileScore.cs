using Microsoft.Azure.Functions.Worker;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace RecruitmentAzureApp
{
    public class CandidateProfileScore
    {
        private readonly ILogger<CandidateProfileScore> _logger;
        private readonly DataverseService _dataverseService;

        public CandidateProfileScore(
            ILogger<CandidateProfileScore> logger,
            DataverseService dataverseService)
        {
            _logger = logger;
            _dataverseService = dataverseService;
        }


        [Function("CountingProfileScore")]
        public void Run(
            [TimerTrigger("*/30 * * * * *")] TimerInfo timer)
        {
            _logger.LogInformation(
                "Profile score calculation started");


            var service =
                _dataverseService.GetService();


            QueryExpression query =
                new QueryExpression("ky_candidate");


            query.ColumnSet =
                new ColumnSet(

                    "ky_fullname",
                    "ky_email",
                    "ky_phonenumber",
                    "ky_gender",
                    "ky_education",
                    "ky_othereducation",
                    "ky_branch",
                    "ky_otherbranch",
                    "ky_collegename",
                    "ky_percentage",
                    "ky_graduationyear",
                    "ky_country",
                    "ky_city",
                    "ky_address",
                    "ky_experiencelevel",
                    "ky_currentctc",
                    "ky_previousrole",
                    "ky_totalyearsofexperience",
                    "ky_noticeperiod"
                );


            EntityCollection candidates =
                service.RetrieveMultiple(query);


            foreach (Entity candidate in candidates.Entities)
            {
                try
                {
                    int totalFields = 0;
                    int filledFields = 0;


                    CheckField(
                        candidate,
                        "ky_fullname",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_email",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_phonenumber",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_gender",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_education",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_branch",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_collegename",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_percentage",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_graduationyear",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_country",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_city",
                        ref totalFields,
                        ref filledFields);

                    CheckField(
                        candidate,
                        "ky_address",
                        ref totalFields,
                        ref filledFields);



                    // Education = Other
                    OptionSetValue education =
                        candidate.GetAttributeValue<OptionSetValue>(
                            "ky_education");

                    if (education != null &&
                        education.Value == 6)
                    {
                        CheckField(
                            candidate,
                            "ky_othereducation",
                            ref totalFields,
                            ref filledFields);
                    }



                    // Branch = Other
                    OptionSetValue branch =
                        candidate.GetAttributeValue<OptionSetValue>(
                            "ky_branch");

                    if (branch != null &&
                        branch.Value == 9) 
                    {
                        CheckField(
                            candidate,
                            "ky_otherbranch",
                            ref totalFields,
                            ref filledFields);
                    }



                    // Experience = Experienced
                    OptionSetValue experience =
                        candidate.GetAttributeValue<OptionSetValue>(
                            "ky_experiencelevel");

                    if (experience != null &&
                        experience.Value == 2) 
                    {
                        CheckField(
                            candidate,
                            "ky_currentctc",
                            ref totalFields,
                            ref filledFields);

                        CheckField(
                            candidate,
                            "ky_previousrole",
                            ref totalFields,
                            ref filledFields);

                        CheckField(
                            candidate,
                            "ky_totalyearsofexperience",
                            ref totalFields,
                            ref filledFields);

                        CheckField(
                            candidate,
                            "ky_noticeperiod",
                            ref totalFields,
                            ref filledFields);
                    }



                    int score =
                        (filledFields * 100)
                        / totalFields;



                    Entity updateCandidate =
                        new Entity(
                            "ky_candidate");


                    updateCandidate.Id =
                        candidate.Id;


                    updateCandidate[
                        "ky_profilescore"] =
                        score;



                    service.Update(
                        updateCandidate);



                    _logger.LogInformation(
                        $"Updated : {candidate.Id} Score : {score}");
                }
                catch (Exception ex)
                {
                    _logger.LogError(
                        ex.Message);
                }
            }


            _logger.LogInformation(
                "Profile score calculation completed");
        }



        private void CheckField(
            Entity entity,
            string fieldName,
            ref int totalFields,
            ref int filledFields)
        {
            totalFields++;


            if (entity.Contains(fieldName) &&
                entity[fieldName] != null)
            {
                filledFields++;
            }
        }
    }
}