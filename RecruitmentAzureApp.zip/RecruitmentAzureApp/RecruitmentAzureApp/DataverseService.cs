﻿using System;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;


namespace RecruitmentAzureApp
{
    public class DataverseService
    {
        private readonly ILogger<DataverseService> _logger;

        public DataverseService(ILogger<DataverseService> logger)
        {
            _logger = logger;
        }

        public ServiceClient GetService()
        {
            try
            {
                string url = Environment.GetEnvironmentVariable("DataverseUrl");
                string clientId = Environment.GetEnvironmentVariable("ClientId");
                string clientSecret = Environment.GetEnvironmentVariable("ClientSecret");
                string tenantId = Environment.GetEnvironmentVariable("TenantId");

                string connectionString =
                    $"AuthType=ClientSecret;Url={url};ClientId={clientId};ClientSecret={clientSecret};TenantId={tenantId};";

                ServiceClient service = new ServiceClient(connectionString);

                if (!service.IsReady)
                {
                    _logger.LogError("Dataverse connection failed");
                    throw new Exception("Dataverse connection failed");
                }

                return service;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception: {ex.Message}");
                throw;
            }
        }
    }
}
