﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace RecruitmentApp.BusinessLogic
{
    public class ApplicationLogic
    {
        public void PreventDuplicateApplication(
                        Entity application,
                        IOrganizationService service,
                        ITracingService tracing)
        {
            tracing.Trace(
                "PreventDuplicateApplication started.");


            if (!application.Contains("ky_candidate") ||
                !application.Contains("ky_role"))
            {
                tracing.Trace(
                    "Candidate or Role missing.");

                return;
            }


            EntityReference candidateRef =
                application.GetAttributeValue<EntityReference>(
                    "ky_candidate");


            EntityReference roleRef =
                application.GetAttributeValue<EntityReference>(
                    "ky_role");


            QueryExpression query =
                new QueryExpression("ky_application");


            query.ColumnSet =
                new ColumnSet(false);


            query.Criteria.AddCondition(
                "ky_candidate",
                ConditionOperator.Equal,
                candidateRef.Id);


            query.Criteria.AddCondition(
                "ky_role",
                ConditionOperator.Equal,
                roleRef.Id);


            EntityCollection applications =
                service.RetrieveMultiple(query);


            if (applications.Entities.Count > 0)
            {
                tracing.Trace(
                    "Duplicate application found.");

                throw new InvalidPluginExecutionException(
                    "Candidate has already applied for this role.");
            }


            tracing.Trace(
                "Duplicate validation passed.");
        }


        // =====================================
        // CREATE
        // =====================================
        public void ApplicationCreatePlugin(
                        IPluginExecutionContext context,
                        IOrganizationService service,
                        ITracingService tracing)
        {
            tracing.Trace(
                "ApplicationCreatePlugin started.");


            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity application)
            {
                if (application.Contains(
                    "ky_candidate"))
                {
                    EntityReference candidateRef =
                        application.GetAttributeValue<EntityReference>(
                            "ky_candidate");


                    UpdateApplicationCount(
                        service,
                        candidateRef.Id,
                        tracing);
                }
            }
        }



        // =====================================
        // DELETE
        // =====================================
        public void ApplicationDeletePlugin(
                        IPluginExecutionContext context,
                        IOrganizationService service,
                        ITracingService tracing)
        {
            tracing.Trace(
                "ApplicationDeletePlugin started.");


            if (context.PreEntityImages
                .Contains("PreImage"))
            {
                Entity preImage =
                    context.PreEntityImages[
                        "PreImage"];


                if (preImage.Contains(
                    "ky_candidate"))
                {
                    EntityReference candidateRef =
                        preImage.GetAttributeValue<EntityReference>(
                            "ky_candidate");


                    UpdateApplicationCount(
                        service,
                        candidateRef.Id,
                        tracing);
                }
            }
        }



        // =====================================
        // COMMON METHOD
        // =====================================
        public void UpdateApplicationCount(
                        IOrganizationService service,
                        Guid candidateId,
                        ITracingService tracing)
        {
            tracing.Trace(
                "UpdateApplicationCount started.");


            QueryExpression query =
                new QueryExpression(
                    "ky_application");


            query.ColumnSet =
                new ColumnSet(false);


            query.Criteria.AddCondition(
                "ky_candidate",
                ConditionOperator.Equal,
                candidateId);


            EntityCollection applications =
                service.RetrieveMultiple(
                    query);


            int count =
                applications.Entities.Count;


            Entity candidate =
                new Entity(
                    "ky_candidate");


            candidate.Id =
                candidateId;



            candidate[
                "ky_countofapplications"]
                = count;


            service.Update(
                candidate);


            tracing.Trace(
                "Application count updated : "
                + count);
        }


        public void ValidatePercentageEligibility(
                    Entity application,
                    IOrganizationService service,
                    ITracingService tracing)
        {
            tracing.Trace(
                "ValidatePercentageEligibility started.");


            if (!application.Contains("ky_candidate") ||
                !application.Contains("ky_role"))
            {
                return;
            }


            EntityReference candidateRef =
                application.GetAttributeValue<EntityReference>(
                    "ky_candidate");


            EntityReference roleRef =
                application.GetAttributeValue<EntityReference>(
                    "ky_role");


            // ==========================
            // GET CANDIDATE
            // ==========================
            Entity candidate =
                service.Retrieve(
                    "ky_candidate",
                    candidateRef.Id,
                    new ColumnSet(
                        "ky_experiencelevel",
                        "ky_percentage"));


            OptionSetValue experienceLevel =
                candidate.GetAttributeValue<OptionSetValue>(
                    "ky_experiencelevel");


         
            int fresherOption = 1;


            // Experienced candidates skip

            if (experienceLevel == null ||
                experienceLevel.Value != fresherOption)
            {
                tracing.Trace(
                    "Experienced candidate. Validation skipped.");

                return;
            }


            // ==========================
            // CHECK CANDIDATE %
            // ==========================

            if (!candidate.Contains(
                "ky_percentage"))
            {
                throw new InvalidPluginExecutionException(
                    "Please update your academic percentage before applying.");
            }


            decimal candidatePercentage =
                candidate.GetAttributeValue<decimal>(
                    "ky_percentage");


            // ==========================
            // GET ROLE
            // ==========================

            Entity role =
                service.Retrieve(
                    "ky_role",
                    roleRef.Id,
                    new ColumnSet(
                        "ky_percentage"));


            // Role percentage missing

            if (!role.Contains(
                "ky_percentage"))
            {
                throw new InvalidPluginExecutionException(
                    "Role eligibility criteria is not configured.");
            }


            decimal rolePercentage =
                role.GetAttributeValue<decimal>(
                    "ky_percentage");


            // ==========================
            // COMPARE
            // ==========================

            if (candidatePercentage <
                rolePercentage)
            {
                throw new InvalidPluginExecutionException(
                    "You are Not Eligible Because You have lesser percentage than required.");
            }

        }

        public void SetDefaultApplicationStatus(
            Entity application,
            ITracingService tracing)
        {
            tracing.Trace(
                "SetDefaultApplicationStatus Started");


            // Applied = 1
            application["ky_applicationstatus"] =
                new OptionSetValue(1);


            tracing.Trace(
                "Application Status Set To Applied");
        }

    }
}