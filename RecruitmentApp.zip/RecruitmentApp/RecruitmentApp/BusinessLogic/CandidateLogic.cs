﻿using Microsoft.Xrm.Sdk;
using System;

namespace RecruitmentApp.BusinessLogic
{
    public class CandidateLogic
    {
        public void ValidateExperienceDetails(
            Entity candidate,
            ITracingService tracing)
        {
            tracing.Trace("ValidateExperienceDetails started.");

            // Check if experience level exists
            if (!candidate.Contains("ky_experiencelevel"))
            {
                tracing.Trace("Experience level not present.");
                return;
            }

            OptionSetValue experienceLevel =
                candidate.GetAttributeValue<OptionSetValue>(
                    "ky_experiencelevel");

            if (experienceLevel == null)
            {
                tracing.Trace("Experience level is null.");
                return;
            }

            // Replace with actual option set value for Experienced
            int experiencedOption = 2;

            // Validate only for experienced candidates
            if (experienceLevel.Value == experiencedOption)
            {
                tracing.Trace("Experienced candidate detected.");

                string previousRole =
                    candidate.GetAttributeValue<string>(
                        "ky_previousrole");

                int? noticePeriod =
                    candidate.GetAttributeValue<int?>(
                        "ky_noticeperiod");

                int? currentCtc =
                    candidate.GetAttributeValue<int?>(
                        "ky_currentctc");

                int? yearsOfExperience =
                    candidate.GetAttributeValue<int?>(
                        "ky_totalyearsofexperience");

                /*
                 Required fields:
                 ky_previousrole
                 ky_totalyearsofexperience
                 ky_currentctc
                 ky_noticeperiod
                 ky_experiencelevel
                */

                if (string.IsNullOrWhiteSpace(previousRole) ||
                    yearsOfExperience == null ||
                    currentCtc == null ||
                    noticePeriod == null)
                {
                    tracing.Trace(
                        "Experience details missing.");

                    throw new InvalidPluginExecutionException(
                        "Please fill all experienced candidate details before saving.");
                }

                tracing.Trace(
                    "Experience validation passed.");
            }
        }
    }
}