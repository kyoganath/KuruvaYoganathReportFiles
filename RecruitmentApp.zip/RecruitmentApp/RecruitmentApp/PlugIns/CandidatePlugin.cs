﻿using RecruitmentApp.BusinessLogic;
using Microsoft.Xrm.Sdk;
using System;

namespace RecruitmentApp.Plugins
{
    public class CandidatePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracing =
                (ITracingService)serviceProvider.GetService(
                    typeof(ITracingService));

            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(
                    typeof(IPluginExecutionContext));

            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(
                    typeof(IOrganizationServiceFactory));

            IOrganizationService service =
                factory.CreateOrganizationService(
                    context.UserId);

            try
            {
                if (context.Depth > 1)
                    return;


                CandidateLogic logic =
                    new CandidateLogic();


                // CANDIDATE CREATE
                if (context.MessageName.ToLower() == "create" &&
                    context.PrimaryEntityName == "ky_candidate" &&
                    context.Stage == 20)
                {
                    if (context.InputParameters.Contains("Target") &&
                        context.InputParameters["Target"] is Entity candidate)
                    {
                        logic.ValidateExperienceDetails(
                            candidate,
                            tracing);
                    }
                }


                // CANDIDATE UPDATE

                else if (context.MessageName.ToLower() == "update" &&
                         context.PrimaryEntityName == "ky_candidate" &&
                         context.Stage == 10)
                {
                    if (context.InputParameters.Contains("Target") &&
                        context.InputParameters["Target"] is Entity candidate)
                    {
                        if (candidate.Contains(
                            "ky_experiencelevel"))
                        {
                            logic.ValidateExperienceDetails(
                                candidate,
                                tracing);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracing.Trace(
                    "Candidate Plugin Error: "
                    + ex.ToString());

                throw;
            }
        }
    }
}