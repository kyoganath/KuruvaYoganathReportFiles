﻿using RecruitmentApp.BusinessLogic;
using Microsoft.Xrm.Sdk;
using System;

namespace RecruitmentApp.Plugins
{
    public class ApplicationPlugin : IPlugin
    {
        public void Execute(
                        IServiceProvider serviceProvider)
        {
            ITracingService tracing =
                (ITracingService)serviceProvider.GetService(
                    typeof(ITracingService));


            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(
                    typeof(IPluginExecutionContext));


            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(
                    typeof(IOrganizationServiceFactory));


            IOrganizationService service =
                factory.CreateOrganizationService(
                    context.UserId);


            try
            {
                if (context.Depth > 1)
                    return;


                ApplicationLogic logic =
                    new ApplicationLogic();


                if (context.MessageName.ToLower() == "create" &&
                    context.PrimaryEntityName ==
                    "ky_application" &&
                    context.Stage == 20)
                {
                    if (context.InputParameters
                        .Contains("Target") &&
                        context.InputParameters["Target"]
                        is Entity application)
                    {
                        logic.PreventDuplicateApplication(
                            application,
                            service,
                            tracing);


                        // Plugin 4
                        logic.ValidatePercentageEligibility(
                            application,
                            service,
                            tracing);

                        logic.SetDefaultApplicationStatus(
                                application,
                                tracing);

                    }


                }

                else if (context.MessageName.ToLower() == "create" &&
                        context.PrimaryEntityName ==
                        "ky_application" &&
                        context.Stage == 40)
                {
                    logic.ApplicationCreatePlugin(
                        context,
                        service,
                        tracing);
                }


                // DELETE → count update

                else if (context.MessageName.ToLower() == "delete" &&
                         context.PrimaryEntityName ==
                         "ky_application" &&
                         context.Stage == 40)
                {
                    logic.ApplicationDeletePlugin(
                        context,
                        service,
                        tracing);
                }


            }
            catch (Exception ex)
            {
                tracing.Trace(
                    "Application Plugin Error : "
                    + ex.ToString());

                throw;
            }
        }
    }
}